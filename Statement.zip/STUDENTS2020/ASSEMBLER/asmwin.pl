#!perl

$WordSize = 16;
$ImmSize = 8;
$DispSize = 9;

%OpCodes =
    (
# STOP and NOP are not in this associative array because we do not
# need to consult them here to construct their binary representation.
     
# First the easiest ones:
     LD, "001",
     ST, "010",
     
# Now all variations of the ADD instructions. The name SUB is also
# taken into account for a couple of additions which are used for
# subtracting     
     ADD, "011",
     ADDc, "011", 
     ADDi, "011",    
     ADDci, "011",
     ADDs,  "011",
     ADDcs, "011", 
     ADDis, "011",    
     ADDcis, "011", 
     ADDu, "011",
     ADDcu, "011", 
     ADDiu, "011",    
     ADDciu, "011",
     ADDsu,  "011",
     ADDcsu, "011", 
     ADDisu, "011",    
     ADDcisu, "011",   
     SUB, "011",  # A more understandable name than ADDci 
     SUBs, "011", # A more understandable name than ADDcis

# Now all the logical instructions, some with dual names:    
     AND, "100",
     OR, "100",
     NOR, "100",
     XOR, "100",
     ANDi, "100",
     ORi, "100",
     NORi, "100",
     XORi, "100",
     ANDs, "100",
     ORs, "100",
     NORs, "100",
     XORs, "100",
     ANDis, "100",
     ORis, "100",
     NORis, "100",
     XORis, "100",     
     XNOR, "100",  # Another name for XORi
     XNORs, "100",  # Another name for XORis
     
# The Jump instructions: 
     JNEV, "101",    
     JALW, "101",
     JZ, "101",
     JNZ, "101",
     JLE, "101",
     JB, "101", 
     JL, "101", 
     JBE, "101", 
     JBEU, "101", 
     JLU, "101",
     JBU, "101",
     JLEU, "101",
     JN, "101",
     JP, "101",    
     JV, "101",  
     JNV, "101",
     
 # The Branch instructions: 
     BNEV, "110",
     BALW, "110",
     BZ, "110",
     BNZ, "110",
     BLE, "110",
     BB, "110", 
     BL, "110", 
     BBE, "110", 
     BBEU, "110", 
     BLU, "110",
     BBU, "110",
     BLEU, "110", 
     BN, "110",
     BP, "110",    
     BV, "110",  
     BNV, "110",

# And the immediate operand instructions:     
     LDIL, "111",
     LDIX, "111",    
     ORIH, "111",
     ADDIX, "111",
);    
     
%ExtOpcodes = 
    (
# First the easiest ones:
     LD, "0000",
     ST, "0000",
     
# Now all variations of the ADD instructions also the name SUB is used
# for a couple of additions which are used for subtracting
     ADD, "0000",
     ADDc, "0001", 
     ADDi, "1000",    
     ADDci, "1001",
     ADDs,  "0100",
     ADDcs, "0101", 
     ADDis, "1100",    
     ADDcis, "1101", 
     ADDu, "0010",
     ADDcu, "0011", 
     ADDiu, "1010",    
     ADDciu, "1011",
     ADDsu,  "0110",
     ADDcsu, "0111", 
     ADDisu, "1110",    
     ADDcisu, "1111",   
     SUB, "1001",  # A more understandable name than ADDci 
     SUBs, "1101", # A more understandable name than ADDcis


# Now all the logical instructions, some with dual names:    
     AND, "0000",
     OR, "0001",
     NOR, "0010",
     XOR, "0011",
     ANDi, "1000",
     ORi, "1001",
     NORi, "1010",
     XORi, "1011",
     ANDs, "0100",
     ORs, "0101",
     NORs, "0110",
     XORs, "0111",
     ANDis, "1100",
     ORis, "1101",
     NORis, "1110",
     XORis, "1111",     
     XNOR, "1011",  # Another name for XORi
     XNORs, "1111",  # Another name for XORis
     
     # The Jump instructions:
     JNEV, "0000",    
     JALW, "1000",
     JZ, "0001",
     JNZ, "1001",
     JLE, "0010",
     JB, "1010", 
     JL, "0011", 
     JBE, "1011", 
     JBEU, "0100", 
     JLU, "1100",
     JBU, "0101",
     JLEU, "1101",
     JN, "0110",
     JP, "1110",    
     JV,   "0111",  
     JNV, "1111",

 # The Branch instructions: 
     BNEV, "0000",
     BALW, "1000",
     BZ, "0001",
     BNZ, "1001",
     BLE, "0010",
     BB, "1010", 
     BL, "0011", 
     BBE, "1011", 
     BBEU, "0100", 
     BLU, "1100",
     BBTU, "0101",
     BLEU, "1101", 
     BN, "0110",
     BP, "1110",    
     BV, "0111",  
     BNV, "1111"
    );

%ImdType =
    (LDIL, "00",
     LDIX, "01",    
     ORIH, "10",
     ADDIX, "11"
    );

%Registers =
    (R0, "000",
     R1, "001",
     R2, "010",
     R3, "011",
     R4, "100",
     R5, "101",
     R6, "110",
     R7, "111",
     r0, "000",
     r1, "001",
     r2, "010",
     r3, "011",
     r4, "100",
     r5, "101",
     r6, "110",
     r7, "111"
    );


sub ToBinStr {
# Converts a number into a binary string, taking into account the size
# of the binary representation which is given. If the number is
# negative then it produces its two's complement representation. This
# subroutine needs being told whether the user has written or not the
# sign of the number, because if it has not been written, the number
# is supposed to be in natural binary, and so the numerical limits for
# the same number of bits is different.  If the value doesn't fit in
# the size the subroutine warns and produces a message in the errorlog
# file.
    
    local($number, $size, $sign) = @_;
    if($sign eq "+" | $sign eq "-"){
	$limit = 2**($size -1);}
    else {$limit = (2**$size)}	
    if ($number > $limit -1 || $number < -$limit){
	print($ERRORLOG "Bad value: $number in line: $linenumber\n");
	return "-INVALID-";}
    elsif($number < 0){
	$number += 2**$size;}
    $string="";
    for($i=1; $i <= $size ; $i++){
	if ($number % 2){
	    $string="1".$string;}
	else{
	    $string="0".$string;} 
	$number/=2;
    }
    return $string;
}	


$linenumber = 0; 
$ProgCounter = 0;
$HexPC = sprintf('%.4X', $ProgCounter);
$HexInstr= "";   
$filename = $ARGV[0];
$BinData ="";
open ($AsmFile,"<", $filename) || die "can't open $filename for reading: $!\n";
open ($OUTPUT, " >", "out.txt") || die "can't open out.txt for writing: $!\n";
open ($ERRORLOG, " >", "ERRORS.txt") || die "can't open ERRORS.txt for writing: $!\n";
while(<$AsmFile>){
    $linenumber++;
    
    # Load, Store, Arithmetic, Logic and Jumps:
    if (/\s*(\w+)\s+(r\d+|R\d+)\s+(r\d+|R\d+)\s+(r\d+|R\d+)\s*\;.*/)
    {
	$TheInstrCode=$OpCodes{$1};
	$DReg=$Registers{$2}; 
	$S1Reg= $Registers{$3}; 
	$S2Reg = $Registers{$4};
	$Extension=$ExtOpcodes{$1};
	if (length($TheInstrCode)!=3){
	    print($ERRORLOG "Bad instruction name: $1 in line: $linenumber\n");
	    $TheInstrCode="XXX";
	}
	if (length($DReg)!=3){	
	    print($ERRORLOG "Bad destination register: $2 in line: $linenumber\n");
	    $DReg="XXX";
	}
 	if (length($S1Reg)!=3){	
	    print($ERRORLOG "Bad source register 1: $3 in line:  $linenumber\n");
	    $S1Reg="XXX";
	}
 	if (length($S2Reg)!=3){	
	    print($ERRORLOG "Bad source register 2: $4 in line: $linenumber\n");
	    $S2Reg="XXX";
	}
	if (length($Extension)!=4){
	    print($ERRORLOG "Instruction: $1 in line: $linenumber does not admit this format\n");
	    $Extension="XXXX";
	}
	$Code = $TheInstrCode.$DReg.$S1Reg.$S2Reg.$Extension;
	$HexInstr = sprintf('%.4X', oct("0b".$Code)); 
	print($OUTPUT $Code."    ", $HexPC.": ",  $HexInstr."  ", $1." ", $2." ", $3." ", $4."; ", "\n");
        $ProgCounter+=1; 
        $HexPC = sprintf('%.4X', $ProgCounter);   
    }
    
    # Branches
    elsif (/\s*(B\w+)\s+(-?|\+)((0x[0-9A-F]+)|(\d+))\s*\;.*/){
	$TheInstrCode=$OpCodes{$1};
	$Sign=$2; 
	$HexValue=$4;
	$DecValue=$5;
	$Value = hex($HexValue) + $DecValue;
	$Value =  -$Value if ($Sign eq "-");	
	$displacement = &ToBinStr($Value,$DispSize,$Sign);
	$Extension = $ExtOpcodes{$1};
	if (length($TheInstrCode)!=3){
	    print($ERRORLOG "Bad instruction name: $1 in line: $linenumber\n");
	    $TheInstrCode="XXX";
	}
	if (length($Extension)!=4){
	    print($ERRORLOG "Instruction: $1 in line: $linenumber does not admit this format\n");
	    $Extension="XXXX";
	}
	$Code=$TheInstrCode.$displacement.$Extension;
	$HexInstr = sprintf('%.4X', oct("0b".$Code));
	print($OUTPUT $Code."    ", $HexPC.": ",  $HexInstr."  ", $1."  ", $2, $4, $5."; ", "\n");
	$ProgCounter+=1;
	$HexPC = sprintf('%.4X', $ProgCounter);
    }
    
    # Immediate
    elsif (/\s*(\w+)\s+(r\d+|R\d+)\s+(\+|-?)((0x[0-9A-F]+)|(\d+))\s*\;.*/){
	$TheInstrCode=$OpCodes{$1};
	$DReg=$Registers{$2};
	$Sign=$3; 
	$HexValue=$5;
	$DecValue=$6;
	$Value = hex($HexValue) + $DecValue;
	$Value = -$Value if ($Sign eq "-");
	$displacement = &ToBinStr($Value, $ImmSize, $Sign);
	$Extension = $ImdType{$1};
	if (length($TheInstrCode)!=3){
	    print($ERRORLOG "Bad instruction name: $1 in line: $linenumber\n");
	    $TheInstrCode="XXX";
	}
	if (length($DReg)!=3){	
	    print($ERRORLOG "Bad destination register: $2 in line: $linenumber\n");
	    $DReg="XXX";
	}	
	if (length($Extension)!=2){
	     print($ERRORLOG "Instruction: $1 in line: $linenumber does not admit this format\n");
	     $Extension="XX";
	}
	$Code=$TheInstrCode.$DReg.$displacement.$Extension; 
	$HexInstr = sprintf('%.4X', oct("0b".$Code)); 
	print($OUTPUT $Code."    ", $HexPC.": ",  $HexInstr."  ", $1." ",$2." ", $3." ", $5."; ", "\n");
	$ProgCounter+=1;
	$HexPC = sprintf('%.4X', $ProgCounter);}
    
    # STOP
    elsif (/STOP\s*\;.*/){
	print($OUTPUT "0000000000000000    ", $HexPC.": ", "0000 ", " STOP", ";\n");
    	$ProgCounter+=1;
	$HexPC = sprintf('%.4X', $ProgCounter);}
    # NOP
    elsif (/NOP\s*\;.*/){
	print($OUTPUT "1010000000000000    ", $HexPC.": ", "A000 ", "NOP", ";\n");
   	$ProgCounter+=1;
	$HexPC = sprintf('%.4X', $ProgCounter);}
    
    # ORG pseudo-instruction
    elsif (/\s*ORG\s+(\+|-?)((0x[0-9A-F]+)|(\d+))\s*\;.*/){
	$Sign=$1;
	$HexValue=$3;
	$DecValue=$4;
	$Value=oct($HexValue)+$DecValue;
	if (($Sign eq "-") || ($Value >= 2**$WordSize)){
	    print($ERRORLOG "Bad address value: $1.$3.$4 of ORG pseudoinstruction in line: $linenumber\n");
	    $Value = "Invalid Address";}
	print($OUTPUT "ORG ", $Value, " ;\n");
	$ProgCounter=$Value;
	$HexPC = sprintf('%.4X', $ProgCounter);}    


    # DATA pseudo-instruction
    elsif (/\s*DATA\s+(\+|-?)((0x[0-9A-F]+)|(\d+))(\s+(\w+))?\s*\;.*/){
	$Sign=$1;
	$HexValue=$3;
	$DecValue=$4;
	$Identifier=$6;
	$Value = hex($HexValue) + $DecValue;
	$Value = -$Value if ($Sign eq "-");
	$BinValue = &ToBinStr($Value,$WordSize,$Sign);
	if (length($BinValue)!=16){
	    print($ERRORLOG "Bad value value: $2.$3.$4 in line: $linenumber\n");
	    $BinValue = "Invalid Value";}	    
	print($OUTPUT $BinValue."    ", $HexPC.": ", "DATA ", $1.$3.$4, $5,  ";\n");
	$ProgCounter=+1;
	$HexPC = sprintf('%.4X', $ProgCounter);}    
 
    # Comments
    elsif (/\#(.*)/){
	print($OUTPUT "#", $1, "\n");}
    
    # Empty lines
    elsif (/^(\s*)$/){
	print($OUTPUT "#\n");}
    
    # Let us discard having missed a semicolon
    elsif(/(.*)\;.*/){
	print($ERRORLOG "Instruction: ", $1, ";", "\n in line: $linenumber has an unknown format\n");  
	print($OUTPUT "XXXXXXXXXXXXXXXX ", $HexPC.": ", $1, ";\n");
	$ProgCounter=+1;
	$HexPC = sprintf('%.4X', $ProgCounter);}
    
    # If we are here at least it means it lacks a semicolon
     elsif(/(.*)/){
	 print($ERRORLOG "Instruction: $1 \n in line: $linenumber has no semicolon (;)\n");
	 print($OUTPUT "XXXXXXXXXXXXXXXX ", $HexPC.": ", $1, "\n");
	$ProgCounter=+1;
	$HexPC = sprintf('%.4X', $ProgCounter);} 
}
    
